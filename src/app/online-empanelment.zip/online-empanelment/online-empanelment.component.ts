import {Component, OnInit, ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'app-online-empanelment',
  templateUrl: './online-empanelment.component.html',
  styleUrls: ['./online-empanelment.component.scss'],
})
export class OnlineEmpanelmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
